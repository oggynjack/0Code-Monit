Move to https://github.com/louislam/uptime-kuma/blob/master/CONTRIBUTING.md
