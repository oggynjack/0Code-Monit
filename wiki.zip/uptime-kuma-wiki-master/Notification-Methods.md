Uptime Kuma supports a lot of notifications.

For native support platforms, please read here:

[https://github.com/louislam/uptime-kuma/tree/master/server/notification-providers](https://github.com/louislam/uptime-kuma/tree/master/server/notification-providers)

Uptime Kuma is integrated Apprise which supports up to 78+ notification services. You can read the full list here:

https://github.com/caronc/apprise/wiki
