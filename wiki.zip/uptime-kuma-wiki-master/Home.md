Welcome to the Uptime Kuma wiki!

## 🐻?

Kuma (クマ/熊) means bear 🐻 in Japanese.

A little bear is watching your website.🐻🐻🐻

### Pronunciation

https://ipa-reader.com/?text=%CB%88%CA%8Cpta%C9%AAm%20k%C9%AF%CC%9F%E1%B5%9Dma%CC%A0&voice=Joey

## How to contribute to this wiki?

You could make a pull request in this wiki repo: https://github.com/louislam/uptime-kuma-wiki

## History

[![Star History Chart](https://api.star-history.com/svg?repos=louislam/uptime-kuma&type=Date)](https://star-history.com/#louislam/uptime-kuma&Date)

- (2021-08-21) Reach 1001 Stargazers, thanks everyone!
- (2021-08-26) Reach 2066 Stargazers. Grow so fast! That is unexpected!
- (2021-08-31) Reach 2651 Stargazers. Amazing!
- (2021-09-06) Reach 3066 Stargazers. 👀👏
- (2021-09-12) Docker Pull is over 1M!
- (2021-09-17) 🐣

  <img src="https://user-images.githubusercontent.com/1336778/133796976-1ea682f5-0cfa-4c50-b6fd-7d879744b12f.jpg" width="250" />

- (2021-09-29) Reach 3645 Stargazers. 👍
- (2021-09-30) Docker Pull is over 2M! Crazy🤪
- (2021-10-07) Reach 4212 🔭✨⭐.
- (2021-10-08) Reach 4764 Stargazers. One of trending projects of the day!
- (2021-10-11) Reach 6658 Stargazers. Is it a rocket🚀?
- (2021-10-13) Docker Pull is over 3M!
- (2021-10-21) Docker Pull is over 4M! ⭐ It's over 8000! https://www.youtube.com/watch?v=TSQqUfeyHF8

  <img src="https://user-images.githubusercontent.com/1336778/138208120-09a6d4b2-ceca-4380-ba59-5456b72a80aa.jpg" width="250" />

- (2021-10-27) Docker Pull is over 5M!
- (2021-11-08) Docker Pull is over 6.7M! 9242 Stargazers!
- (2021-11-18) Docker Pull is over 8M!
- (2021-12-01) Docker Pull is over 10M!
- (2021-12-02) Reach 10,076 Stargazers!
- (2022-01-21) Reach 12,059 Stargazers!
- (2022-03-02) Docker Pull is over 25M! 14,050 Stargazers!
- (2022-04-10) 15,629 Stargazers!
- (2022-10-09) 21,975 Stargazers! Over 20K! Another Milestone!🐻👍
- (2023-01-09) {"⭐": 27783, "🐳": 31688853 }
- (2023-02-06) let starCount = 29141; let dockerPullCount = 32185677;
- (2023-02-26) `<div class="⭐">30,063</div><div class="🐳">32,606,170</div>`
- (2023-05-11) ⭐33132,🐳34513470
- (2023-10-09) ⭐39263,🐳44805032
- (2023-11-03) ⭐40093,🐳47255050
- (2023-12-05) ⭐42,297 🐳51,241,294
- (2024-04-05) ⭐48,341 🐳68,668,482
- (2024-10-16) ⭐57,263 🐳93,911,095
- (2024-11-20) ⭐60,027 🐳96,146,195
- (2024-12-20) ⭐61,495 🐳98,033,822
- (2025-05-20) ⭐69,648 🐳109,485,043 + 426,361
