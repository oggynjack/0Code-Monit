## With Docker

```bash
docker exec -it <container name> bash
npm run reset-password
```

## Without Docker

cd to the working directory.

```bash
npm run reset-password
```
